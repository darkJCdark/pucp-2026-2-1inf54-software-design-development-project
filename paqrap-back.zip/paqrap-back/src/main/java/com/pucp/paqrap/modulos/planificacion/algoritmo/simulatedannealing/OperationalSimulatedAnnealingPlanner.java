package com.pucp.paqrap.modulos.planificacion.algoritmo.simulatedannealing;

import com.pucp.paqrap.modulos.pedidos.entity.Order;
import com.pucp.paqrap.modulos.planificacion.algoritmo.common.OperationalPlanEvaluator;
import com.pucp.paqrap.modulos.planificacion.algoritmo.common.PlanEvaluation;
import com.pucp.paqrap.modulos.planificacion.algoritmo.common.ResultadoPlanificacion;
import com.pucp.paqrap.modulos.planificacion.entity.OperationalPlan;
import com.pucp.paqrap.modulos.planificacion.entity.OperationalSnapshot;
import com.pucp.paqrap.modulos.redvial.entity.RoadBlock;

import java.util.Collection;
import java.util.List;
import java.util.Objects;
import java.util.random.RandomGenerator;

/** Pure-Java simulated annealing over the common PaqRap operational model. */
public final class OperationalSimulatedAnnealingPlanner {
    /** Upper bound accepted for a wall-clock budget (one day), as in the numerical experiment. */
    public static final long PRESUPUESTO_MAXIMO_MS = 86_400_000L;
    private static final long SIN_LIMITE = -1L;

    private final OperationalPlanEvaluator evaluator;
    private final OperationalNeighborGenerator neighborGenerator;
    private final InitialPlanBuilder initialPlanBuilder;

    public OperationalSimulatedAnnealingPlanner(OperationalPlanEvaluator evaluator) {
        this(evaluator, new OperationalRouteNeighborGenerator());
    }

    OperationalSimulatedAnnealingPlanner(OperationalPlanEvaluator evaluator,
                                         OperationalNeighborGenerator neighborGenerator) {
        this.evaluator = Objects.requireNonNull(evaluator, "evaluator is required");
        this.neighborGenerator = Objects.requireNonNull(neighborGenerator, "neighborGenerator is required");
        this.initialPlanBuilder = new InitialPlanBuilder(evaluator);
    }

    /** Public backend result consumed by the planning service. */
    public ResultadoPlanificacion planificar(OperationalSnapshot snapshot, Collection<Order> orders,
                                             List<RoadBlock> blocks, AnnealingConfig config,
                                             RandomGenerator random) {
        return ejecutar(snapshot, orders, blocks, config, random).resultado();
    }

    /**
     * Same search bounded by a wall-clock budget measured from the start of the call (the initial plan
     * is included, as in the numerical experiment). When the budget expires the search stops and the
     * best plan found so far is returned. The initial plan construction itself cannot be interrupted.
     */
    public ResultadoPlanificacion planificar(OperationalSnapshot snapshot, Collection<Order> orders,
                                             List<RoadBlock> blocks, AnnealingConfig config,
                                             RandomGenerator random, long presupuestoMs) {
        if (presupuestoMs <= 0 || presupuestoMs > PRESUPUESTO_MAXIMO_MS) {
            throw new IllegalArgumentException("presupuestoMs must be within (0, " + PRESUPUESTO_MAXIMO_MS + "]");
        }
        return ejecutar(snapshot, orders, blocks, config, random, presupuestoMs).resultado();
    }

    /** Package-private metrics support deterministic tests without exposing a second backend result. */
    Ejecucion ejecutar(OperationalSnapshot snapshot, Collection<Order> orders, List<RoadBlock> blocks,
                       AnnealingConfig config, RandomGenerator random) {
        return ejecutar(snapshot, orders, blocks, config, random, SIN_LIMITE);
    }

    Ejecucion ejecutar(OperationalSnapshot snapshot, Collection<Order> orders, List<RoadBlock> blocks,
                       AnnealingConfig config, RandomGenerator random, long presupuestoMs) {
        long inicioNanos = System.nanoTime();
        long limiteNanos = presupuestoMs == SIN_LIMITE ? SIN_LIMITE : presupuestoMs * 1_000_000L;
        Objects.requireNonNull(snapshot, "snapshot is required");
        Objects.requireNonNull(orders, "orders are required");
        Objects.requireNonNull(blocks, "blocks are required");
        Objects.requireNonNull(config, "config is required");
        Objects.requireNonNull(random, "random is required");

        InitialPlanBuilder.SeedPlan seed = initialPlanBuilder.build(snapshot, orders, blocks);
        if (seed.attended().isEmpty()) {
            PlanEvaluation emptyEvaluation = evaluator.evaluate(OperationalPlan.empty(), snapshot, List.of(), blocks);
            return new Ejecucion(new ResultadoPlanificacion(OperationalPlan.empty(), emptyEvaluation, seed.unattended()),
                    0.0, 0, 0, 0, config.initialTemperature());
        }

        PlanEvaluation initialEvaluation = evaluator.evaluate(seed.plan(), snapshot, seed.attended(), blocks);
        if (!initialEvaluation.isFeasible()) {
            throw new IllegalStateException("Initial SA plan must be feasible: " + initialEvaluation.violations());
        }
        SearchResult search = optimize(seed.plan(), initialEvaluation, snapshot, seed.attended(), blocks, config, random,
                inicioNanos, limiteNanos);
        ResultadoPlanificacion result = new ResultadoPlanificacion(search.bestPlan(), search.bestEvaluation(), seed.unattended());
        return new Ejecucion(result, initialEvaluation.totalCost(), search.evaluatedNeighbors(),
                search.acceptedNeighbors(), search.iterations(), search.finalTemperature());
    }

    private SearchResult optimize(OperationalPlan initial, PlanEvaluation initialEvaluation,
                                  OperationalSnapshot snapshot, Collection<Order> requiredOrders,
                                  List<RoadBlock> blocks, AnnealingConfig config, RandomGenerator random,
                                  long inicioNanos, long limiteNanos) {
        OperationalPlan current = initial;
        OperationalPlan best = initial;
        PlanEvaluation currentEvaluation = initialEvaluation;
        PlanEvaluation bestEvaluation = initialEvaluation;
        double temperature = config.initialTemperature();
        int iterations = 0;
        int evaluated = 0;
        int accepted = 0;
        int withoutImprovement = 0;

        while (temperature >= config.minimumTemperature()
                && iterations < config.maximumIterations()
                && withoutImprovement < config.maximumIterationsWithoutImprovement()
                && !tiempoAgotado(inicioNanos, limiteNanos)) {
            for (int levelIteration = 0; levelIteration < config.iterationsPerTemperature()
                    && iterations < config.maximumIterations()
                    && !tiempoAgotado(inicioNanos, limiteNanos); levelIteration++) {
                iterations++;
                var candidate = neighborGenerator.generate(current, snapshot, random);
                if (candidate.isEmpty()) continue;
                evaluated++;
                PlanEvaluation candidateEvaluation = evaluator.evaluate(candidate.get(), snapshot, requiredOrders, blocks);
                if (!candidateEvaluation.isFeasible()) continue;

                double delta = candidateEvaluation.totalCost() - currentEvaluation.totalCost();
                if (accept(delta, temperature, random)) {
                    current = candidate.get();
                    currentEvaluation = candidateEvaluation;
                    accepted++;
                }
                if (currentEvaluation.totalCost() < bestEvaluation.totalCost()) {
                    best = current;
                    bestEvaluation = currentEvaluation;
                    withoutImprovement = 0;
                } else {
                    withoutImprovement++;
                }
            }
            temperature *= config.coolingFactor();
        }
        return new SearchResult(best, bestEvaluation, evaluated, accepted, iterations, temperature);
    }

    private static boolean tiempoAgotado(long inicioNanos, long limiteNanos) {
        return limiteNanos != SIN_LIMITE && System.nanoTime() - inicioNanos >= limiteNanos;
    }

    static boolean accept(double delta, double temperature, RandomGenerator random) {
        return delta <= 0 || random.nextDouble() < Math.exp(-delta / temperature);
    }

    record Ejecucion(ResultadoPlanificacion resultado, double initialCost, int evaluatedNeighbors,
                     int acceptedNeighbors, int iterations, double finalTemperature) { }

    private record SearchResult(OperationalPlan bestPlan, PlanEvaluation bestEvaluation, int evaluatedNeighbors,
                                int acceptedNeighbors, int iterations, double finalTemperature) { }
}
