package com.pucp.paqrap.modulos.planificacion.algoritmo.common;
import com.pucp.paqrap.modulos.almacenes.entity.*;
import com.pucp.paqrap.modulos.flota.entity.*;
import com.pucp.paqrap.modulos.flota.service.*;
import com.pucp.paqrap.modulos.incidencias.entity.*;
import com.pucp.paqrap.modulos.incidencias.service.*;
import com.pucp.paqrap.modulos.pedidos.entity.*;
import com.pucp.paqrap.modulos.planificacion.algoritmo.common.*;
import com.pucp.paqrap.modulos.planificacion.entity.*;
import com.pucp.paqrap.modulos.redvial.entity.*;
import com.pucp.paqrap.modulos.redvial.service.*;

import com.pucp.paqrap.modulos.pedidos.entity.Order;
import com.pucp.paqrap.modulos.planificacion.entity.OperationalPlan;
import com.pucp.paqrap.modulos.planificacion.algoritmo.common.PlanEvaluation;

import java.util.List;

/**
 * Envuelve un OperationalPlan + PlanEvaluation del dominio compartido.
 * noAtendidos: pedidos que ninguna unidad pudo atender en esta iteración
 * (el plan inicial de SA los deja fuera), nunca enviados al evaluador para que no
 * vuelvan infactible el plan completo (decisión confirmada por el docente).
 */
public record ResultadoPlanificacion(OperationalPlan plan, PlanEvaluation evaluacion, List<Order> noAtendidos) {
    public double costoTotal() {
        return evaluacion.totalCost();
    }

    public boolean esFactible() {
        return evaluacion.isFeasible();
    }

    /** Senal explicita de colapso logistico: quedo al menos un pedido sin
     *  atender en el MEJOR resultado que el planificador encontro tras
     *  todas sus iteraciones. No es lo mismo que esFactible()==false --
     *  un plan puede ser factible (sus rutas cumplen todas las reglas) y
     *  aun asi haber colapsado porque no le alcanzo la flota/tiempo para
     *  cubrir toda la demanda. Se calcula sobre el resultado FINAL ya
     *  elegido, no por iteracion intermedia -- evita tener que restar
     *  "49 de 50" a mano para notar que el escenario no se resolvio del
     *  todo. Es una senal del ciclo de SA, no el colapso logistico del
     *  escenario: ese lo declara DetectorColapso (plazo vencido o
     *  inalcanzable), porque SA puede no hallar una solucion que existe.
     */
    public boolean esColapso() {
        return !noAtendidos.isEmpty();
    }
}
